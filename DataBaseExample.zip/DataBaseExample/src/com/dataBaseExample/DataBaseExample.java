package com.dataBaseExample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DataBaseExample {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String courseID = "";
		String instructor = "";
		String status = "";
		int cap = 2;
		int enrolled = 0;
		//User inputs
		System.out.print("Please eneter the course id : ");
		courseID = sc.nextLine();
		
		System.out.print("Please eneter the Instructors id : ");
		instructor = sc.nextLine();
		
		//connection 
		String url = "jdbc:mysql://cobmysql.uhcl.edu/undavallit1408?useSSL=false";
		
		String loginId = "undavallit1408";
		String password = "2441408";
		
		Connection con= null;
		
		Statement stat = null;
		
		ResultSet rs = null;
		
		try {
			//Connect With the DB
			con = DriverManager.getConnection(url,loginId,password);
			
			//statement
			stat = con.createStatement();
			
			//Set auto update to false
			//if anything wrong , the prog rolls back to here
			con.setAutoCommit(false);
			
			int t = stat.executeUpdate("insert into Course values('"+ courseID + "','" 
			+ instructor + "','" + cap + "',' " + enrolled + "',' " + status + "')");
			
			con.commit();//commit the transaction
			con.setAutoCommit(true);
			
			System.out.println("The Insertion is Successfull");
			
		}catch(SQLException e) {
			//handle with the eXCEPTION
			System.out.println("The insertion was not successfull");
			e.printStackTrace();//This displays stack of exception in LIFO(IN A STACK)
			
		}
		finally {
			//CLOSES THE DB 
			try {
				con.close();
				stat.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		//statement 
		
		//ResultSet
		
	}

}
